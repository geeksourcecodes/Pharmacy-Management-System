<div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <!-- BEGIN: Footer-->
    <footer class="footer footer-static footer-light navbar-shadow">
        <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2"><span class="float-md-left d-block d-md-inline-block">Copyright &copy; <?php echo date('Y');?> <a class="text-bold-800 grey darken-2" href="" ><?=$footer?></a></span><span class="float-md-right d-none d-lg-block">Hand-crafted & Made with <i class="ft-heart pink"></i><span id="scroll-top"></span></span></p>
    </footer>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    <script src="../assets/admin/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="../assets/admin/vendors/js/ui/jquery.sticky.js"></script>
    <script src="../assets/admin/vendors/js/charts/jquery.sparkline.min.js"></script>
    <script src="../assets/admin/vendors/js/tables/jquery.dataTables.min.js"></script>
    <script src="../assets/admin/vendors/js/tables/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="../assets/admin/vendors/js/tables/datatable/dataTables.responsive.min.js"></script>
    <script src="../assets/admin/vendors/js/tables/datatable/dataTables.rowReorder.min.js"></script>
    <script src="../assets/admin/vendors/js/forms/icheck/icheck.min.js"></script>
    <script src="../assets/admin/js/core/libraries/jquery_ui/jquery-ui.min.js"></script>
    <script src="../assets/admin/js/scripts/ui/jquery-ui/date-pickers.js"></script>
    <script src="../assets/admin/vendors/js/forms/select/select2.min.js"></script>
    <!-- END: Page Vendor JS-->

    <script src="../assets/admin/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js"></script>
    <script src="../assets/admin/vendors/js/forms/validation/jqBootstrapValidation.js"></script>
    <script src="../assets/admin/vendors/js/forms/toggle/switchery.min.js"></script>

    <!-- BEGIN: Theme JS-->
    <script src="../assets/admin/js/core/app-menu.js"></script>
    <script src="../assets/admin/js/core/app.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="../assets/admin/js/scripts/ui/breadcrumbs-with-stats.js"></script>
    <script src="../assets/admin/js/scripts/pages/project-task-list.js"></script>
    <!-- END: Page JS-->

    <script src="../assets/admin/js/scripts/tables/datatables/datatable-advanced.js"></script>
    <script src="../assets/admin/js/tables/datatable/datatables.min.js"></script>
    <script src="../assets/admin/js/tables/datatable/dataTables.buttons.min.js"></script>
    <script src="../assets/admin/js/scripts/forms/validation/form-validation.js"></script>
    <script src="../assets/admin/vendors/js/forms/validation/jqBootstrapValidation.js"></script>
    <script src="../assets/admin/vendors/js/extensions/sweetalert.min.js"></script>
    <script src="../assets/admin//vendors/js/extensions/toastr.min.js"></script>
    <script src="../assets/admin/js/scripts/extensions/toastr.js"></script>
<script>
    window.setTimeout(function() {
        $(".alert").fadeTo(400, 0).slideUp(400, function(){
            $(this).remove(); 
        });
    }, 4000);
</script>
</body>
<!-- END: Body-->

</html>