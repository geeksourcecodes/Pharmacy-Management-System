<?php
//database settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pharmacy1";

$currency = "INR";
/*date_default_timezone_set('Africa/Dar_es_salaam');*/

date_default_timezone_set('Asia/Kolkata');

//Installation - Include the last slash
$instalation_dir = "http://localhost/pharmacy/";

//Mail settings
$smtp_host = 'smtp.gmail.com';
$smtp_user = 'onlineexams285@gmail.com';
$smtp_pass = 'EJWGVROGIYIQNHVB';
